
#ifndef tempo_H
#define tempo_H 

#include "FslTypes.h"

void delay_10us(void);
void delay_100us(void);
void delay_1ms(void);
void delay_250ms(void);
void DelayMs(UINT16 count);


#endif /* tempo_H */
